Run the assembler like so:

$ python 06b.py <relative path to .asm file>

  or

$ ./06b.py <relative path to .asm file>

For example:

$ python 06b.py add/Add.asm
