#!/usr/bin/env python

#============================================================
# USERID:......... KMANZANA
# PROGRAMMER:..... Manzanares, Kelton M.
# COURSE:......... CSCI-410
# TERM:........... SP14
# PROJECT:........ 06B
# FILENAME:....... 06b.py
# PYTHON VERSION:. 2.7.2
#============================================================

from main import Main

Main().main()
