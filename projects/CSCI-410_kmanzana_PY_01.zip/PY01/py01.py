from Main import Main

main = Main()
main.main()
