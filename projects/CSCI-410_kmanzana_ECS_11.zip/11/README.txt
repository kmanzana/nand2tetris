Example usage:

./projects/11/JackCompiler.py ./projects/11/Snake

  or

python ./projects/11/JackCompiler.py ./projects/11/Snake
