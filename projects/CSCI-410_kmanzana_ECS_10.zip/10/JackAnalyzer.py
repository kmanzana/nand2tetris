#!/usr/bin/env python

#============================================================
# USERID:......... KMANZANA
# PROGRAMMER:..... Manzanares, Kelton M.
# COURSE:......... CSCI-410
# TERM:........... SP14
# PROJECT:........ ECS10
# FILENAME:....... JackAnalyzer.py
# PYTHON VERSION:. 2.7.2
#============================================================

from Main import Main

Main().main()
