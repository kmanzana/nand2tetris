Run the assembler like so:

$ python 06a.py <relative path to .asm file>

For example:

$ python 06a.py add/Add.asm
